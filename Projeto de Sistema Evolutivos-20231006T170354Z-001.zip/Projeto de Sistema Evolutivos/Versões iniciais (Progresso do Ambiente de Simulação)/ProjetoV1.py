from deap import creator, base, tools, algorithms
import random
import arcade
import math
import numpy as np

toolbox = base.Toolbox()

SPRITE_SCALING_PLAYER = 0.25
SPRITE_SCALING_OBSTACLE = 0.1
SCREEN_WIDTH = 1200
SCREEN_HEIGHT = 700
OBSTACLE_COUNT = 40
PLAYER_COUNT = 2


# Funcao Sigmoid
def sigmoid(z):
    return 1.0/(1.0+np.exp(-z))


# Definindo o Obstaculo
class Obstacle(arcade.Sprite):
    def __init__(self, filename, sprite_scaling):
        # Componentes do Jogador
        super().__init__(filename, sprite_scaling)
        self.velX = random.randrange(-1, 2, 2)*2.5
        self.velY = random.randrange(-1, 2, 2)*2.5
        self.center_x = random.randrange(SCREEN_WIDTH)
        self.center_y = random.randrange(SCREEN_HEIGHT)

    def update(self):
        self.center_x += self.velX
        self.center_y += self.velY
        if self.center_x < 0 or self.center_x > SCREEN_WIDTH:
            self.velX *= -1
        if self.center_y < 0 or self.center_y > SCREEN_HEIGHT:
            self.velY *= -1


# Definindo o Jogador
class Player(arcade.Sprite):
    def __init__(self, filename, sprite_scaling):
        # Componentes do Jogador
        super().__init__(filename, sprite_scaling)
        self.time = 0
        self.velX = 2.5
        self.velY = 2.5
        self.center_x = SCREEN_WIDTH/2
        self.center_y = SCREEN_HEIGHT/2
        self.nearObstacles = set()
        self.qtdNearObstacles = 0
        # Componentes da Rede Neural
        self.sizes = [OBSTACLE_COUNT+1, OBSTACLE_COUNT+1, 1]
        self.weights = []

    def update(self):
        # Acrescentando o tempo
        self.time += 1 / 2400
        # "Raciocinio"
        a = [[0.0, 0.0]]
        for obs in self.nearObstacles:
            a.append([obs.center_x - self.center_x, obs.center_y-self.center_y])
        a.sort()
        ax = []
        ay = []
        for i in a:
            ax.append(i[0])
            ay.append(i[1])
        for w in self.weights:
            try:
                tamanho = len(ax)
            except:
                tamanho = 1
            ax = sigmoid(np.array(np.dot(w[:tamanho], ax)))
            ay = sigmoid(np.array(np.dot(w[:tamanho], ay)))

        # Movimento em X
        if ax < 0.33 and self.center_x > self.velX:
            self.center_x -= self.velX
        elif ax > 0.66 and self.center_x < SCREEN_WIDTH:
            self.center_x += self.velX
        # Movimento em Y
        if ay < 0.33 and self.center_y > self.velY:
            self.center_y -= self.velY
        elif ay > 0.66 and self.center_y < SCREEN_HEIGHT:
            self.center_y += self.velY


def evaluate(pesos):
    player_list = []
    obstacle_list = []
    component_list = []
    for i in pesos:
        individual = Player(":resources:images/animated_characters/female_person/"
                            "femalePerson_idle.png", SPRITE_SCALING_PLAYER)
        individual.weights = i

        # Adicionando individuo às listas
        component_list.append(individual)
        player_list.append(individual)

    # Criando Obstaculos
    for i in range(OBSTACLE_COUNT):
        new_obstacle = Obstacle(":resources:images/items/coinGold.png", SPRITE_SCALING_OBSTACLE)
        obstacle_list.append(new_obstacle)
        component_list.append(new_obstacle)

    cabou = 0

    while cabou == 0:
        # Adicionar obstáculos próximos
        for ind in player_list:
            for obstacle in obstacle_list:
                dist = math.sqrt((ind.center_x - obstacle.center_x) ** 2 +
                                 (ind.center_y - obstacle.center_y) ** 2)
                if dist <= 100.0:
                    ind.nearObstacles.add(obstacle)
                    ind.qtdNearObstacles += 1

        # Retira obstaculos que sairam do raio
        for ind in player_list:
            for obstacle in ind.nearObstacles.copy():
                dist = math.sqrt((ind.center_x - obstacle.center_x) ** 2 +
                                 (ind.center_y - obstacle.center_y) ** 2)
                if dist > 100:
                    ind.nearObstacles.remove(obstacle)
                    ind.qtdNearObstacles -= 1

        # Atualizar posições de componentes
        for componente in component_list:
            componente.update()

        # Verificar colisão, imprimir tempo e eliminar jogador
        for ind in player_list:
            for obstacle in obstacle_list:
                if ind.center_x == obstacle.center_x and ind.center_y == obstacle.center_y:
                    component_list.remove(ind)
                    player_list.remove(ind)
                    if len(player_list) == 0:
                        return ind.time,


# Parte Evolutiva
sizes = [OBSTACLE_COUNT+1, OBSTACLE_COUNT+1, 1]


def gerapesos():
    return [np.random.uniform(0, 1, x) for x in sizes[:-1]]


# Definicoes
creator.create("FitnessMax", base.Fitness, weights=(1.0, ))

creator.create("Individual", list, fitness=creator.FitnessMax)

toolbox.register("weights", gerapesos)

toolbox.register("individual", tools.initRepeat, creator.Individual, toolbox.weights, n=10)

toolbox.register("evaluate", evaluate)

toolbox.register("population", tools.initRepeat, list, toolbox.individual, n=PLAYER_COUNT)

toolbox.register("mate", tools.cxTwoPoint)

toolbox.register("mutate", tools.mutShuffleIndexes, indpb=0.2)

toolbox.register("select", tools.selTournament, tournsize=3)


# Avaliando o modelo
NGEN = 4

pop = toolbox.population()
CXPB = 0.5
MUTPB = 0.2
population = toolbox.population()
for gen in range(NGEN):
    offspring = algorithms.varAnd(population, toolbox, cxpb=0.8, mutpb=0.5)
    fits = toolbox.map(toolbox.evaluate, offspring)
    print("   fitness: ", fits)
    for fit, ind in zip(fits, offspring):
        ind.fitness.values = fit
        print("f: ", ind.fitness.values)
    population = toolbox.select(offspring, k=len(population))
    print('.  Selected:\n', population)
    top1 = tools.selBest(population, k=1)
    print(".  Best found at generation {}: {}".format(gen, top1))
