from deap import creator, base, tools, algorithms
import random
import arcade
import math
import numpy as np

toolbox = base.Toolbox()

SPRITE_SCALING_PLAYER = 0.25
SPRITE_SCALING_OBSTACLE = 0.1
OBSTACLE_COUNT = 40
PLAYER_COUNT = 5

SCREEN_WIDTH = 1200
SCREEN_HEIGHT = 700
SCREEN_TITLE = "Sprite trying to survive"


# Funcao Sigmoid
def sigmoid(z):
    return 1.0/(1.0+np.exp(-z))


# Definindo o Obstaculo
class Obstacle(arcade.Sprite):
    def __init__(self, filename, sprite_scaling):
        # Componentes do Jogador
        super().__init__(filename, sprite_scaling)
        self.velX = random.randrange(-1, 2, 2)*5.0
        self.velY = random.randrange(-1, 2, 2)*5.0
        self.center_x = random.randrange(SCREEN_WIDTH)
        self.center_y = random.randrange(SCREEN_HEIGHT)

    def update(self):
        self.center_x += self.velX
        self.center_y += self.velY
        if self.center_x < 0 or self.center_x > SCREEN_WIDTH:
            self.velX *= -1
        if self.center_y < 0 or self.center_y > SCREEN_HEIGHT:
            self.velY *= -1


# Definindo o Jogador
class Player(arcade.Sprite):
    def __init__(self, filename, sprite_scaling):
        # Componentes do Jogador
        super().__init__(filename, sprite_scaling)
        self.time = 0
        self.velX = 5.0
        self.velY = 5.0
        self.center_x = SCREEN_WIDTH/2
        self.center_y = SCREEN_HEIGHT/2
        self.nearObstacles = set()
        self.qtdNearObstacles = 0
        # Componentes da Rede Neural
        self.sizes = [OBSTACLE_COUNT+1, 1]
        self.weights = []

    def update(self):
        # Acrescentando o tempo
        self.time += 1 / 2400
        # "Raciocinio"
        a = []
        for obs in self.nearObstacles:
            a.append([obs.center_x - self.center_x, obs.center_y - self.center_y])
        a.sort()
        ax = []
        ay = []
        cont = 0
        ax.append(0.0)
        ay.append(0.0)
        for i in a:
            ax.append(i[0])
            ay.append(i[1])
        ax = np.array(ax)
        ay = np.array(ay)
        for w in self.weights:
            if len(ax) != 1:
                if cont == 0:
                    try:
                        tamanho = len(ax)
                    except:
                        tamanho = 1
                    ax = sigmoid(np.dot(w[:, :tamanho], ax))
                    ay = sigmoid(np.dot(w[:, :tamanho], ay))
                else:
                    ax = sigmoid(np.dot(w, ax))
                    ay = sigmoid(np.dot(w, ay))
            cont += 1
        """
            try:
                tamanho = len(ax)
            except:
                tamanho = 1
            ax = sigmoid(np.array(np.dot(self.weights[:tamanho], ax)))
            ay = sigmoid(np.array(np.dot(self.weights[:tamanho], ay)))
        """
        # Movimento em X
        if ax[0] < 0.33 and self.center_x < SCREEN_WIDTH - (self.width / 1.5):
            self.center_x += self.velX
        elif ax[0] > 0.66 and self.center_x > self.width / 1.5:
            self.center_x -= self.velX
        # Movimento em Y
        if ay[0] > 0.66 and self.center_y < SCREEN_HEIGHT - (self.width / 1.5):
            self.center_y += self.velY
        elif ay[0] < 0.33 and self.center_y > self.width / 1.5:
            self.center_y -= self.velY


def evaluate(pesos):
    player_list = []
    obstacle_list = []
    component_list = []
    for i in pesos:
        individual = Player(":resources:images/animated_characters/female_person/"
                            "femalePerson_idle.png", SPRITE_SCALING_PLAYER)
        individual.weights = i

        # Adicionando individuo às listas
        component_list.append(individual)
        player_list.append(individual)

    # Criando Obstaculos
    for i in range(OBSTACLE_COUNT):
        new_obstacle = Obstacle(":resources:images/items/coinGold.png", SPRITE_SCALING_OBSTACLE)
        obstacle_list.append(new_obstacle)
        component_list.append(new_obstacle)

    cabou = 0

    while cabou == 0:
        # Adicionar obstáculos próximos
        for ind in player_list:
            for obstacle in obstacle_list:
                dist = math.sqrt((ind.center_x - obstacle.center_x) ** 2 +
                                 (ind.center_y - obstacle.center_y) ** 2)
                if dist <= 100.0:
                    ind.nearObstacles.add(obstacle)
                    ind.qtdNearObstacles += 1

        # Retira obstaculos que sairam do raio
        for ind in player_list:
            for obstacle in ind.nearObstacles.copy():
                dist = math.sqrt((ind.center_x - obstacle.center_x) ** 2 +
                                 (ind.center_y - obstacle.center_y) ** 2)
                if dist > 100:
                    ind.nearObstacles.remove(obstacle)
                    ind.qtdNearObstacles -= 1

        # Atualizar posições de componentes
        for componente in component_list:
            componente.update()

        # Verificar colisão, imprimir tempo e eliminar jogador
        for ind in player_list:
            for obstacle in obstacle_list:
                if ind.center_x == obstacle.center_x and ind.center_y == obstacle.center_y:
                    component_list.remove(ind)
                    player_list.remove(ind)
                    if len(player_list) == 0:
                        return ind.time,


# Parte Evolutiva
sizes = [OBSTACLE_COUNT+1, 5, 1]


def gerapesos():
    return [np.random.uniform(0, 1, (y, x)) for x, y in zip(sizes[:-1], sizes[1:])]


# Definicoes
creator.create("FitnessMax", base.Fitness, weights=(1.0, ))

creator.create("Individual", list, fitness=creator.FitnessMax)

toolbox.register("weights", gerapesos)

toolbox.register("individual", tools.initRepeat, creator.Individual, toolbox.weights, n=PLAYER_COUNT)

toolbox.register("evaluate", evaluate)

toolbox.register("population", tools.initRepeat, list, toolbox.individual, n=10)

toolbox.register("mate", tools.cxTwoPoint)

toolbox.register("mutate", tools.mutShuffleIndexes, indpb=0.2)

toolbox.register("select", tools.selTournament, tournsize=3)


# Avaliando o modelo
NGEN = 5
bestweight = []
CXPB = 0.5
MUTPB = 0.2
population = toolbox.population()
for gen in range(NGEN):
    offspring = algorithms.varAnd(population, toolbox, cxpb=0.8, mutpb=0.5)
    fits = toolbox.map(toolbox.evaluate, offspring)
    print("   fitness: ", fits)
    for fit, ind in zip(fits, offspring):
        ind.fitness.values = fit
        print("f: ", ind.fitness.values)
    population = toolbox.select(offspring, k=len(population))
    # print('.  Selected:\n', population)
    top1 = tools.selBest(population, k=1)
    print(".  Best found at generation {}: {}".format(gen, top1))


# Ambiente de Simulação
class MyGame(arcade.Window):
    """ Our custom Window Class"""

    def __init__(self):
        """ Initializer """
        # Call the parent class initializer
        super().__init__(SCREEN_WIDTH, SCREEN_HEIGHT, SCREEN_TITLE)

        # Variables that will hold sprite lists
        self.all_sprites_list = None
        self.obstacle_list = None
        self.player_list = None

        # Set up the player info
        # self.player_sprite = None
        self.score = 0

        # Don't show the mouse cursor
        self.set_mouse_visible(False)

        arcade.set_background_color(arcade.color.AMAZON)

    def setup(self):
        """ Set up the game and initialize the variables. """

        # Sprite lists
        self.all_sprites_list = arcade.SpriteList()
        self.player_list = arcade.SpriteList()
        self.obstacle_list = arcade.SpriteList()

        # Score
        self.score = 0

        # Set up the player
        # Character image from kenney.nl
        for i in range(PLAYER_COUNT):
            player = Player(":resources:images/animated_characters/female_person/"
                            "femalePerson_idle.png", SPRITE_SCALING_PLAYER)

            player.weights = top1[0][i]

            # Add player to lists
            self.all_sprites_list.append(player)
            self.player_list.append(player)

        # Create the obstacles
        for i in range(OBSTACLE_COUNT):

            # creating obstacle
            obstacle = Obstacle(":resources:images/items/coinGold.png", SPRITE_SCALING_OBSTACLE)

            # Position the obstacle
            obstacle.center_x = random.randrange(SCREEN_WIDTH)
            obstacle.center_y = random.randrange(SCREEN_HEIGHT)
            obstacle.change_x = random.randrange(-1, 2, 2)*2.5
            obstacle.change_y = random.randrange(-1, 2, 2)*2.5

            # Add the obstacle to the lists
            self.all_sprites_list.append(obstacle)
            self.obstacle_list.append(obstacle)

    def on_draw(self):
        """ Draw everything """
        self.clear()
        output = f"Time: {round(self.score, 2)}"
        arcade.draw_text(output, 15, 20, arcade.color.WHITE, 14)
        self.all_sprites_list.draw()

        # Put the text on the screen.
        output = f"Time: {round(self.score, 2)}"
        survivors = f"Sobreviventes: {len(self.player_list)}"
        arcade.draw_text(output, 15, 20, arcade.color.WHITE, 14)
        arcade.draw_text(survivors, 150, 20, arcade.color.WHITE, 14)

    def on_update(self, delta_time):
        """ Movement and game logic """
        self.score += 1 / 60
        # Call update on all sprites (The sprites don't do much in this
        # example though.)
        self.all_sprites_list.update()

        # Generate a list of all sprites that collided with the player.
        # Adicionar obstáculos próximos
        for player in self.player_list:
            for obstacle in self.obstacle_list:
                dist = math.sqrt((player.center_x - obstacle.center_x) ** 2 +
                                 (player.center_y - obstacle.center_y) ** 2)
                if dist <= 100.0:
                    player.nearObstacles.add(obstacle)
                    player.qtdNearObstacles += 1

        # Retira obstaculos que sairam do raio
        for player in self.player_list:
            for obstacle in player.nearObstacles.copy():
                dist = math.sqrt((player.center_x - obstacle.center_x) ** 2 +
                                 (player.center_y - obstacle.center_y) ** 2)
                if dist > 100.0:
                    player.nearObstacles.remove(obstacle)
                    player.qtdNearObstacles -= 1
        # Verificar colisão, imprimir tempo e eliminar jogador
        for player in self.player_list:
            hit_list = arcade.check_for_collision_with_list(player, self.obstacle_list)
            if len(hit_list) != 0:
                # player.remove_from_sprite_lists(self.player_list)
                player.remove_from_sprite_lists()
        if len(self.player_list) == 0:
            self.setup()

        # Loop through each colliding sprite, remove it, and add to the score.


def main():
    window = MyGame()
    window.setup()
    arcade.run()


main()
