from deap import creator, base, tools, algorithms
import random
import arcade
import math
import numpy as np

# Definindo Constantes
toolbox = base.Toolbox()

SPRITE_SCALING_PLAYER = 0.25
SPRITE_SCALING_OBSTACLE = 0.1
OBSTACLE_COUNT = 30
PLAYER_COUNT = 1
VELOCIDADE = 3.0

SCREEN_WIDTH = 1200
SCREEN_HEIGHT = 700
SCREEN_TITLE = "Player trying to survive"


# Funcao Sigmoid
def sigmoid(z):
    return 1.0/(1.0+np.exp(-z))

# Funcao projecao ort ponto reta
def projecaoPontoReta(P, O, v):
    x = (v[0] * v[1] * (P[1] - O[1]) + (v[0] ** 2) * P[0] + (v[1] ** 2) * O[0]) / ((v[0] ** 2) + (v[1] ** 2))
    y = (v[0] * v[1] * (P[0] - O[0]) + (v[0] ** 2) * O[1] + (v[1] ** 2) * P[1]) / ((v[0] ** 2) + (v[1] ** 2))
    return x, y

# Funcao distancia ponto reta
def distanciaPontoReta(AP, v):
    return (AP[0]*v[1] - AP[1]*v[0])/math.sqrt(math.pow(v[0], 2) + math.pow(v[1], 2))

# Definindo o Obstaculo
class Obstacle(arcade.Sprite):
    def __init__(self, filename, sprite_scaling):
        # Componentes do Jogador
        super().__init__(filename, sprite_scaling)
        self.velX = random.randrange(-1, 2, 2)*VELOCIDADE
        self.velY = random.randrange(-1, 2, 2)*VELOCIDADE
        self.center_x = random.randrange(SCREEN_WIDTH)
        self.center_y = random.randrange(SCREEN_HEIGHT)

    def update(self):
        self.center_x += self.velX
        self.center_y += self.velY
        if self.center_x < 0 or self.center_x > SCREEN_WIDTH:
            self.velX *= -1
        if self.center_y < 0 or self.center_y > SCREEN_HEIGHT:
            self.velY *= -1


# Definindo o Jogador
class Player(arcade.Sprite):
    def __init__(self, filename, sprite_scaling):
        # Componentes do Jogador
        super().__init__(filename, sprite_scaling)
        self.time = 0
        self.velX = VELOCIDADE
        self.velY = VELOCIDADE
        self.center_x = SCREEN_WIDTH/2
        self.center_y = SCREEN_HEIGHT/2
        self.nearObstacles = set()
        self.qtdNearObstacles = 0
        # Componentes da Rede Neural
        self.weights = []

    def update(self):
        # Acrescentando o tempo
        self.time += 1 / 120
        # "Raciocinio"
        a = []
        for obs in self.nearObstacles:
            m = projecaoPontoReta((self.center_x, self.center_y), (obs.center_x, obs.center_y), (obs.velX, obs.velY))
            a.append([m[0] - self.center_x, m[1] - self.center_y])
        a.sort()
        ax = []
        ay = []
        cont = 0
        ax.append(0.0)
        ay.append(0.0)
        ax.append(self.center_x * (-1))
        ay.append(self.center_y * (-1))
        ax.append(SCREEN_WIDTH - self.center_x)
        ay.append(SCREEN_HEIGHT - self.center_y)
        for i in a:
            ax.append(i[0])
            ay.append(i[1])
        ax = np.array(ax)
        ay = np.array(ay)
        for w in self.weights:
            if len(ax) != 1:
                if cont == 0:
                    try:
                        tamanho = len(ax)
                    except:
                        tamanho = 1
                    ax = sigmoid(np.dot(w[:, :tamanho], ax))
                    ay = sigmoid(np.dot(w[:, :tamanho], ay))
                else:
                    ax = sigmoid(np.dot(w, ax))
                    ay = sigmoid(np.dot(w, ay))
            cont += 1

        # Movimento em X
        if ax[0] < 0.33 and self.center_x > self.width / 1.5:
            self.center_x -= self.velX
        elif ax[0] > 0.66 and self.center_x < SCREEN_WIDTH - (self.width / 1.5):
            self.center_x += self.velX
        # Movimento em Y
        if ay[0] > 0.66 and self.center_y < SCREEN_HEIGHT - (self.width / 1.5):
            self.center_y += self.velY
        elif ay[0] < 0.33 and self.center_y > self.width / 1.5:
            self.center_y -= self.velY


# Função Evauluate para determinar o tempo de sobrevivência
def evaluate(pesos):
    score = 0
    player_list = arcade.SpriteList()
    obstacle_list = arcade.SpriteList()
    component_list = arcade.SpriteList()

    # Craindo Individuo
    individual = Player(":resources:images/animated_characters/female_person/"
                        "femalePerson_idle.png", SPRITE_SCALING_PLAYER)
    matriz1 = []
    matriz2 = []
    for i in range(quantidade):
        if(i < (OBSTACLE_COUNT+3)*5):
            matriz1.append(pesos[i])
        else:
            matriz2.append(pesos[i])
    matriz1 = np.array(matriz1)
    matriz2 = np.array(matriz2)
    matriz1 = np.reshape(matriz1, (5, OBSTACLE_COUNT+3))
    matriz2 = np.reshape(matriz2, (1, 5))
    individual.weights = [matriz1, matriz2]

    # Adicionando individuo às listas
    component_list.append(individual)
    player_list.append(individual)

    # Criando Obstaculos
    for i in range(OBSTACLE_COUNT):
        new_obstacle = Obstacle(":resources:images/items/coinGold.png", SPRITE_SCALING_OBSTACLE)
        obstacle_list.append(new_obstacle)
        component_list.append(new_obstacle)

    cabou = 0

    while cabou == 0:
        # Adicionar obstáculos próximos
        for ind in player_list:
            for obstacle in obstacle_list:
                dist = math.sqrt((ind.center_x - obstacle.center_x) ** 2 +
                                 (ind.center_y - obstacle.center_y) ** 2)
                if dist <= 200.0:
                    ind.nearObstacles.add(obstacle)
                    ind.qtdNearObstacles += 1

        # Retira obstaculos que sairam do raio
        for ind in player_list:
            for obstacle in ind.nearObstacles.copy():
                dist = math.sqrt((ind.center_x - obstacle.center_x) ** 2 +
                                 (ind.center_y - obstacle.center_y) ** 2)
                if dist > 200:
                    ind.nearObstacles.remove(obstacle)
                    ind.qtdNearObstacles -= 1

        # Atualizar posições de componentes
        component_list.update()

        # Verificar colisão, imprimir tempo e eliminar jogador
        for ind in player_list:
            if ind.time > 50:
                score += ind.time
                component_list.remove(ind)
                player_list.remove(ind)
                continue
            hit_list = arcade.check_for_collision_with_list(ind, obstacle_list)
            if len(hit_list) != 0:
                score += ind.time
                ind.remove_from_sprite_lists()
        if len(player_list) == 0:
            return score/PLAYER_COUNT,


# Parte Evolutiva
sizes = [OBSTACLE_COUNT+3, 5, 1]
quantidade = sizes[0]*sizes[1] + sizes[1]*sizes[2]

# Função para gerar pesos aleatórios
def gerapesos():
    return [np.random.uniform(0, 1, (y, x)) for x, y in zip(sizes[:-1], sizes[1:])]


# Definicoes da Biblioteca Deap
creator.create("FitnessMax", base.Fitness, weights=(1.0, ))

creator.create("Individual", list, fitness=creator.FitnessMax)

toolbox.register("weights", np.random.uniform, 0, 1)

toolbox.register("individual", tools.initRepeat, creator.Individual, toolbox.weights, n=quantidade)

toolbox.register("evaluate", evaluate)

toolbox.register("population", tools.initRepeat, list, toolbox.individual, n=200)

toolbox.register("mate", tools.cxTwoPoint)

toolbox.register("mutate", tools.mutGaussian, mu=0, sigma=1, indpb=0.4)

toolbox.register("select", tools.selTournament, tournsize=3)


# Avaliando o modelo
NGEN = 5
bestweight = []
CXPB = 0.4
MUTPB = 0.4
population = toolbox.population()
for gen in range(NGEN):
    offspring = algorithms.varAnd(population, toolbox, cxpb=CXPB, mutpb=MUTPB)
    fits = toolbox.map(toolbox.evaluate, offspring)
    print(f"Geração {gen}:")
    for fit, ind in zip(fits, offspring):
        ind.fitness.values = fit
        print("score: ", round(ind.fitness.values[0], 2))
    population = toolbox.select(offspring, k=len(population))
    top1 = tools.selBest(population, k=1)


# Ambiente de Simulação
class MyGame(arcade.Window):
    """ Our custom Window Class"""

    def __init__(self):
        """ Initializer """
        # Call the parent class initializer
        super().__init__(SCREEN_WIDTH, SCREEN_HEIGHT, SCREEN_TITLE)

        # Variables that will hold sprite lists
        self.all_sprites_list = None
        self.obstacle_list = None
        self.player_list = None

        # Set up the player info
        # self.player_sprite = None
        self.score = 0

        # Don't show the mouse cursor
        self.set_mouse_visible(False)

        arcade.set_background_color(arcade.color.AMAZON)

    def setup(self):
        """ Set up the game and initialize the variables. """

        # Sprite lists
        self.all_sprites_list = arcade.SpriteList()
        self.player_list = arcade.SpriteList()
        self.obstacle_list = arcade.SpriteList()

        # Score
        self.score = 0

        # Set up the player
        # Character image from kenney.nl
        for i in range(PLAYER_COUNT):
            player = Player(":resources:images/animated_characters/female_person/"
                            "femalePerson_idle.png", SPRITE_SCALING_PLAYER)
            player.velX = VELOCIDADE
            player.velY = VELOCIDADE
            bestpesos = top1[0]
            bestmatriz1 = []
            bestmatriz2 = []
            for i in range(quantidade):
                if (i < (OBSTACLE_COUNT+3) * 5):
                    bestmatriz1.append(bestpesos[i])
                else:
                    bestmatriz2.append(bestpesos[i])
            bestmatriz1 = np.array(bestmatriz1)
            bestmatriz2 = np.array(bestmatriz2)
            bestmatriz1 = np.reshape(bestmatriz1, (5, OBSTACLE_COUNT+3))
            bestmatriz2 = np.reshape(bestmatriz2, (1, 5))
            player.weights = [bestmatriz1, bestmatriz2]


            # Add player to lists
            self.all_sprites_list.append(player)
            self.player_list.append(player)

        # Create the obstacles
        for i in range(OBSTACLE_COUNT):

            # creating obstacle
            obstacle = Obstacle(":resources:images/items/coinGold.png", SPRITE_SCALING_OBSTACLE)

            # Position the obstacle
            obstacle.center_x = random.randrange(SCREEN_WIDTH)
            obstacle.center_y = random.randrange(SCREEN_HEIGHT)
            obstacle.change_x = random.randrange(-1, 2, 2)*VELOCIDADE
            obstacle.change_y = random.randrange(-1, 2, 2)*VELOCIDADE

            # Add the obstacle to the lists
            self.all_sprites_list.append(obstacle)
            self.obstacle_list.append(obstacle)

    def on_draw(self):
        """ Draw everything """
        self.clear()
        output = f"Time: {round(self.score, 2)}"
        arcade.draw_text(output, 15, 20, arcade.color.WHITE, 14)
        self.all_sprites_list.draw()

        # Put the text on the screen.
        output = f"Time: {round(self.score, 2)}"
        survivors = f"Sobreviventes: {len(self.player_list)}"
        arcade.draw_text(output, 15, 20, arcade.color.WHITE, 14)
        arcade.draw_text(survivors, 150, 20, arcade.color.WHITE, 14)

    def on_update(self, delta_time):
        """ Movement and game logic """
        self.score += 1 / 120
        # Call update on all sprites (The sprites don't do much in this
        # example though.)
        self.all_sprites_list.update()

        # Generate a list of all sprites that collided with the player.
        # Adicionar obstáculos próximos
        for player in self.player_list:
            for obstacle in self.obstacle_list:
                dist = math.sqrt((player.center_x - obstacle.center_x) ** 2 +
                                 (player.center_y - obstacle.center_y) ** 2)
                if dist <= 200.0:
                    player.nearObstacles.add(obstacle)
                    player.qtdNearObstacles += 1

        # Retira obstaculos que sairam do raio
        for player in self.player_list:
            for obstacle in player.nearObstacles.copy():
                dist = math.sqrt((player.center_x - obstacle.center_x) ** 2 +
                                 (player.center_y - obstacle.center_y) ** 2)
                if dist > 200.0:
                    player.nearObstacles.remove(obstacle)
                    player.qtdNearObstacles -= 1
        # Verificar colisão, imprimir tempo e eliminar jogador
        for player in self.player_list:
            hit_list = arcade.check_for_collision_with_list(player, self.obstacle_list)
            if len(hit_list) != 0:
                # player.remove_from_sprite_lists(self.player_list)
                player.remove_from_sprite_lists()
        if len(self.player_list) == 0:
            self.setup()

        # Loop through each colliding sprite, remove it, and add to the score.

# Display do ambiente de simulação
def main():
    window = MyGame()
    window.setup()
    arcade.run()


main()